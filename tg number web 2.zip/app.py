from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

API_URL = "https://tg-2-num-api-org.vercel.app/api/search?userid="

@app.route("/", methods=["GET"])
def home():
    return render_template("index.html")

@app.route("/search", methods=["POST"])
def search():
    user_id = request.form.get("userid")

    if not user_id or not user_id.isdigit():
        return jsonify({"error": "Invalid ID"})

    try:
        response = requests.get(API_URL + user_id)
        return response.text
    except:
        return jsonify({"error": "API error"})

if __name__ == "__main__":
    app.run(debug=True)